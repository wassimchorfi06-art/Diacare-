package com.diacare.app

import android.os.Bundle
import android.view.WindowManager
import androidx.core.view.WindowCompat
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // شاشة كاملة بدون status bar شفاف
        WindowCompat.setDecorFitsSystemWindows(window, false)

        // منع الشاشة من الإغلاق أثناء الاستخدام (اختياري)
        // window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
}
